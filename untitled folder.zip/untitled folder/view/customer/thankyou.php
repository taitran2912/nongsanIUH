<?php
// Kiểm tra đăng nhập
if (!isset($_SESSION["id"])) {
    echo "<script>window.location.href = '?action=login';</script>";
    exit;
}

// Kiểm tra xem có mã đơn hàng không
if (!isset($_GET['order_id'])) {
    echo "<script>window.location.href = '?action=cart';</script>";
    exit;
}

$orderId = $_GET['order_id'];
$customerId = $_SESSION["id"];

// Kết nối CSDL
$db = new clsketnoi();
$conn = $db->moKetNoi();
$conn->set_charset('utf8');

// Lấy thông tin đơn hàng
$orderSql = "SELECT o.id, o.order_date, o.total_amount, o.notes, o.Shipping_address, o.status
             FROM orders o
             WHERE o.id = ? AND o.user_id = ?";
$orderStmt = $conn->prepare($orderSql);
$orderStmt->bind_param("ii", $orderId, $customerId);
$orderStmt->execute();
$orderResult = $orderStmt->get_result();

if ($orderResult->num_rows === 0) {
    echo "<script>window.location.href = '?action=cart';</script>";
    exit;
}

$orderInfo = $orderResult->fetch_assoc();

// Lấy chi tiết đơn hàng
$detailsSql = "SELECT od.product_id, od.quantity, p.name, p.price, p.unit
               FROM order_details od
               JOIN products p ON od.product_id = p.id
               WHERE od.order_id = ?";
$detailsStmt = $conn->prepare($detailsSql);
$detailsStmt->bind_param("i", $orderId);
$detailsStmt->execute();
$detailsResult = $detailsStmt->get_result();

$orderDetails = [];
$subtotal = 0;

while ($row = $detailsResult->fetch_assoc()) {
    $orderDetails[] = $row;
    $subtotal += $row['price'] * $row['quantity'];
}

// Tính phí vận chuyển
$shippingFee = ($subtotal >= 500000) ? 0 : 30000;

// Lấy thông tin người dùng
$userSql = "SELECT name, email, phone FROM users WHERE id = ?";
$userStmt = $conn->prepare($userSql);
$userStmt->bind_param("i", $customerId);
$userStmt->execute();
$userResult = $userStmt->get_result();
$userInfo = $userResult->fetch_assoc();

// Đóng kết nối
$db->dongKetNoi($conn);

// Định dạng trạng thái thanh toán
$paymentStatusText = '';
$paymentStatusClass = '';

if ($orderInfo['status'] === '1') {
    $paymentStatusText = 'Đã thanh toán';
    $paymentStatusClass = 'text-success';
} else {
    $paymentStatusText = 'Chưa thanh toán';
    $paymentStatusClass = 'text-warning';
}

// Định dạng trạng thái đơn hàng
$orderStatusText = '';
switch ($orderInfo['status']) {
    case '0':
        $orderStatusText = 'Chờ xử lý';
        break;
    case '1':
        $orderStatusText = 'Đã thanh toán';
        break;
    case '2':
        $orderStatusText = 'Đang xử lý';
        break;
    case '3':
        $orderStatusText = 'Đã hủy';
        break;
    default:
        $orderStatusText = 'Không xác định';
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cảm ơn bạn đã đặt hàng</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .thank-you-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 2rem;
            text-align: center;
        }
        .success-icon {
            font-size: 5rem;
            color: #198754;
            margin-bottom: 1rem;
        }
        .order-info {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 2rem;
            margin: 2rem 0;
            text-align: left;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .order-details {
            margin-top: 2rem;
        }
        .next-steps {
            margin-top: 2rem;
        }
        .step-card {
            height: 100%;
            transition: transform 0.3s;
        }
        .step-card:hover {
            transform: translateY(-5px);
        }
        .step-icon {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: #198754;
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="thank-you-container">
            <div class="success-icon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h1 class="display-4">Cảm ơn bạn đã đặt hàng!</h1>
            <p class="lead">Đơn hàng của bạn đã được xác nhận và đang được xử lý.</p>
            
            <div class="order-info">
                <h4 class="mb-3">Thông tin đơn hàng</h4>
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Mã đơn hàng:</strong> #<?php echo $orderId; ?></p>
                        <p><strong>Ngày đặt hàng:</strong> <?php echo date('d/m/Y H:i', strtotime($orderInfo['order_date'])); ?></p>
                        <p><strong>Phương thức thanh toán:</strong> SePay</p>
                        <p><strong>Trạng thái đơn hàng:</strong> <?php echo $orderStatusText; ?></p>
                        <p><strong>Trạng thái thanh toán:</strong> <span class="<?php echo $paymentStatusClass; ?>"><?php echo $paymentStatusText; ?></span></p>
                    </div>
                    <div class="col-md-6">
                        <p><strong>Tên khách hàng:</strong> <?php echo $userInfo['name']; ?></p>
                        <p><strong>Email:</strong> <?php echo $userInfo['email']; ?></p>
                        <p><strong>Số điện thoại:</strong> <?php echo $userInfo['phone']; ?></p>
                        <p><strong>Địa chỉ giao hàng:</strong> <?php echo $orderInfo['Shipping_address']; ?></p>
                    </div>
                </div>
                
                <div class="order-details">
                    <h5 class="mb-3">Chi tiết đơn hàng</h5>
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Sản phẩm</th>
                                    <th class="text-center">Đơn giá</th>
                                    <th class="text-center">Số lượng</th>
                                    <th class="text-end">Thành tiền</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orderDetails as $item): ?>
                                <tr>
                                    <td><?php echo $item['name']; ?></td>
                                    <td class="text-center"><?php echo number_format($item['price'], 0, ',', '.'); ?>đ/<?php echo $item['unit']; ?></td>
                                    <td class="text-center"><?php echo $item['quantity']; ?></td>
                                    <td class="text-end"><?php echo number_format($item['price'] * $item['quantity'], 0, ',', '.'); ?>đ</td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3" class="text-end"><strong>Tạm tính:</strong></td>
                                    <td class="text-end"><?php echo number_format($subtotal, 0, ',', '.'); ?>đ</td>
                                </tr>
                                <tr>
                                    <td colspan="3" class="text-end"><strong>Phí vận chuyển:</strong></td>
                                    <td class="text-end"><?php echo number_format($shippingFee, 0, ',', '.'); ?>đ</td>
                                </tr>
                                <tr>
                                    <td colspan="3" class="text-end"><strong>Tổng cộng:</strong></td>
                                    <td class="text-end fw-bold text-success"><?php echo number_format($orderInfo['total_amount'], 0, ',', '.'); ?>đ</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            
            <?php if ($orderInfo['status'] === '1'): ?>
            <div class="alert alert-success" role="alert">
                <i class="fas fa-check-circle me-2"></i> Thanh toán đã được xác nhận thành công!
            </div>
            <?php else: ?>
            <div class="alert alert-warning" role="alert">
                <i class="fas fa-clock me-2"></i> Đang chờ xác nhận thanh toán. Vui lòng kiểm tra lại sau ít phút.
            </div>
            <?php endif; ?>
            
            <div class="next-steps">
                <h4 class="mb-4">Bước tiếp theo</h4>
                <div class="row g-4">
                    <div class="col-md-4">
                        <div class="card step-card">
                            <div class="card-body">
                                <div class="step-icon">
                                    <i class="fas fa-box"></i>
                                </div>
                                <h5 class="card-title">Theo dõi đơn hàng</h5>
                                <p class="card-text">Kiểm tra trạng thái đơn hàng của bạn trong tài khoản.</p>
                                <a href="?action=orders" class="btn btn-outline-success">Xem đơn hàng</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card step-card">
                            <div class="card-body">
                                <div class="step-icon">
                                    <i class="fas fa-shopping-basket"></i>
                                </div>
                                <h5 class="card-title">Tiếp tục mua sắm</h5>
                                <p class="card-text">Khám phá thêm các sản phẩm nông sản tươi ngon.</p>
                                <a href="?action=product" class="btn btn-outline-success">Mua sắm</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card step-card">
                            <div class="card-body">
                                <div class="step-icon">
                                    <i class="fas fa-headset"></i>
                                </div>
                                <h5 class="card-title">Hỗ trợ</h5>
                                <p class="card-text">Cần giúp đỡ? Đội ngũ hỗ trợ của chúng tôi luôn sẵn sàng.</p>
                                <a href="?action=contact" class="btn btn-outline-success">Liên hệ</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="mt-5">
                <a href="?action=home" class="btn btn-success btn-lg">
                    <i class="fas fa-home me-2"></i>Quay lại trang chủ
                </a>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
