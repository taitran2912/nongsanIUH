<?php
// Lấy dữ liệu từ webhook
$payload = file_get_contents('php://input');
$headers = getallheaders();

// Ghi log để debug
error_log("SePay Webhook received: " . $payload);

// Kiểm tra xem có dữ liệu không
if (empty($payload)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'No payload received']);
    exit;
}

// Phân tích dữ liệu từ SePay
$data = json_decode($payload, true);

// Kiểm tra dữ liệu
if (!isset($data['gateway']) || $data['gateway'] !== 'SEPAY') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid gateway']);
    exit;
}

// Lấy thông tin giao dịch
$transactionInfo = $data['data'] ?? [];
$transferType = $data['transferType'] ?? '';
$accountNumber = $data['accountNumber'] ?? '';
$subAccount = $data['subAccount'] ?? '';
$amount = $data['amount'] ?? 0;
$content = $data['content'] ?? '';
$referenceCode = $data['referenceCode'] ?? '';
$description = $data['description'] ?? '';
$transactionDateTime = $data['transactionDateTime'] ?? '';

// Kiểm tra loại giao dịch (chỉ xử lý giao dịch nhận tiền)
if ($transferType !== 'in') {
    http_response_code(200);
    echo json_encode(['success' => true, 'message' => 'Not an incoming transaction']);
    exit;
}

// Tìm mã đơn hàng trong nội dung chuyển khoản
$orderCode = '';
if (preg_match('/ORD\d+/', $content, $matches)) {
    $orderCode = $matches[0];
} else {
    // Nếu không tìm thấy mã đơn hàng trong content, thử tìm trong description
    if (preg_match('/ORD\d+/', $description, $matches)) {
        $orderCode = $matches[0];
    }
}

if (empty($orderCode)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Order code not found in transaction content']);
    exit;
}

// Kết nối CSDL
require_once 'config.php'; // Đảm bảo file này chứa class clsketnoi
$db = new clsketnoi();
$conn = $db->moKetNoi();
$conn->set_charset('utf8');

// Tìm đơn hàng theo mã đơn hàng trong notes
$orderSql = "SELECT o.id, o.user_id, o.total_amount, o.status 
             FROM orders o 
             WHERE o.notes LIKE ? AND o.status = '0'";
$orderStmt = $conn->prepare($orderSql);
$searchPattern = '%' . $orderCode . '%';
$orderStmt->bind_param("s", $searchPattern);
$orderStmt->execute();
$orderResult = $orderStmt->get_result();

if ($orderResult->num_rows === 0) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Order not found or already processed']);
    $db->dongKetNoi($conn);
    exit;
}

$orderData = $orderResult->fetch_assoc();

// Kiểm tra số tiền (cho phép sai lệch nhỏ do làm tròn)
$expectedAmount = (float)$orderData['total_amount'];
$receivedAmount = (float)$amount;
$tolerance = 1000; // Cho phép sai lệch 1000đ

if (abs($expectedAmount - $receivedAmount) > $tolerance) {
    http_response_code(400);
    echo json_encode([
        'success' => false, 
        'message' => 'Amount mismatch',
        'expected' => $expectedAmount,
        'received' => $receivedAmount
    ]);
    $db->dongKetNoi($conn);
    exit;
}

// Cập nhật trạng thái đơn hàng thành "đã thanh toán" (1)
$updateOrderSql = "UPDATE orders SET status = '1' WHERE id = ?";
$updateOrderStmt = $conn->prepare($updateOrderSql);
$updateOrderStmt->bind_param("i", $orderData['id']);
$updateOrderStmt->execute();

// Kiểm tra xem bảng transactions đã tồn tại chưa
$checkTableSql = "SHOW TABLES LIKE 'transactions'";
$checkTableResult = $conn->query($checkTableSql);

if ($checkTableResult->num_rows > 0) {
    // Cập nhật trạng thái giao dịch nếu bảng transactions tồn tại
    $updateTransactionSql = "UPDATE transactions SET status = 'completed', transaction_date = NOW() WHERE order_id = ?";
    $updateTransactionStmt = $conn->prepare($updateTransactionSql);
    $updateTransactionStmt->bind_param("i", $orderData['id']);
    $updateTransactionStmt->execute();
}

// Xóa giỏ hàng sau khi thanh toán thành công
$clearCartSql = "DELETE FROM cart WHERE customer_id = ?";
$clearCartStmt = $conn->prepare($clearCartSql);
$clearCartStmt->bind_param("i", $orderData['user_id']);
$clearCartStmt->execute();

// Kiểm tra xem bảng payment_logs đã tồn tại chưa
$checkLogsTableSql = "SHOW TABLES LIKE 'payment_logs'";
$checkLogsTableResult = $conn->query($checkLogsTableSql);

if ($checkLogsTableResult->num_rows > 0) {
    // Ghi log giao dịch nếu bảng payment_logs tồn tại
    $logSql = "INSERT INTO payment_logs (order_id, transaction_code, event, amount, content, payload, created_at) 
               VALUES (?, ?, 'payment.completed', ?, ?, ?, NOW())";
    $logStmt = $conn->prepare($logSql);
    $logStmt->bind_param("issds", $orderData['id'], $referenceCode, $amount, $content, $payload);
    $logStmt->execute();
}

// Đóng kết nối
$db->dongKetNoi($conn);

// Trả về phản hồi thành công
http_response_code(200);
echo json_encode([
    'success' => true, 
    'message' => 'Payment processed successfully',
    'order_id' => $orderData['id'],
    'order_code' => $orderCode
]);
?>
