<script>
    window.location.href = 'view/customer/index.php';
</script>